﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class Projectile : MonoBehaviour {

    public bool good; //good/bad
    public int damage;
    public int fat;
    public int points;
    public bool reflected = false;
    public float lifetime;

    private Rigidbody2D myRB;

    void Start()
    {
        try
        {
            if (GetComponent<Collider2D>() != null && GetComponent<Rigidbody2D>() != null && GetComponent<ConstantForce2D>() != null)
                throw new Exception("Missing component");

            myRB = GetComponent<Rigidbody2D>();
        } catch (Exception e)
        {
            Debug.LogError("Projectile creation failed : " + e);
            Destroy(gameObject);
        }
	}

    private void Update()
    {
        if (GameManager.gameState != GameManager.GameState.Play)
            return;

        lifetime -= Time.deltaTime;

        if (lifetime <= 0)
            Destroy(gameObject);

        myRB.velocity = Vector2.ClampMagnitude(myRB.velocity, 15);
    }

    //Init stats for a good projectile
    public void SetGood(int fattyness, int pointVal)
    {
        good = true;
        fat = fattyness;
        points = pointVal;
        damage = 1;
        GetComponent<SpriteRenderer>().color = Color.green;
    }

    //Init stats for a bad projectile
    public void SetPain(int fattyness, int pointVal, int damageVal)
    {
        good = false;
        fat = fattyness;
        points = pointVal;
        damage = damageVal;
        GetComponent<SpriteRenderer>().color = Color.red;
    }

    //Process collisions
    private void OnCollisionEnter2D(Collision2D coll)
    {
        if (coll.gameObject.tag == "Wall")
        {
            Destroy(gameObject);
        }
    }

}
