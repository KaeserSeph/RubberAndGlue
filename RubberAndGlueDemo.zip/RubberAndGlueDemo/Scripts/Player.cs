﻿using System.Collections;
using System.Collections.Generic;
using System;
using UnityEngine;

public class Player : MonoBehaviour {

    enum Mode
    {
        Glue,
        Nuetral,
        Rubber
    }
    
    public int myHealth;
    public int maxHealth;
    [SerializeField]
    private Mode myMode;
    public float[] modeSpeedMod;
    public float mySize;
    public float sizeIncrement;
    public float minSize;
    public float maxSize;
    public float[] damageMod;
    public Color[] myColors;
    public bool invincible;
    public float invincibleDuration;
    public float bouncePower;
    
    private float invTimer;
    private SpriteRenderer mySR;
    private Rigidbody2D myRB;

    private void Init()
    {
        try
        {
            mySR = GetComponent<SpriteRenderer>();
            myRB = GetComponent<Rigidbody2D>();

            if (myColors.Length != 3 && modeSpeedMod.Length != 3 && myColors.Length != 3 && damageMod.Length != 3)
                throw new Exception("Setting size");
            if (myHealth < 2)
                throw new Exception("myHealth setting");
            if (maxHealth < myHealth)
                throw new Exception("maxHealth setting");
            if (minSize > maxSize)
                throw new Exception("maxSize setting");

            SetMode(false, false);
        } catch(Exception e)
        {
            Debug.LogError("Player Init Critical Failure : " + e);
        }
    }
    
	void Start ()
    {
        Init();
	}
	
	void Update ()
    {
        if (GameManager.gameState != GameManager.GameState.Play)
            return;

        //Update Invincibility
        if (invTimer > 0)
        {
            invTimer -= Time.deltaTime;
            if(invTimer < 0)
            {
                invTimer = 0;
                invincible = false;
            }
        }
	}

    //Set the mode the player is in, update the color, return the speed mod
    public float SetMode(bool rubber, bool glue)
    {
        if ((myMode == Mode.Rubber && rubber) || (myMode == Mode.Glue && glue) || (myMode == Mode.Nuetral && !rubber && !glue))
            return modeSpeedMod[(int)myMode];
        
        if (rubber && !glue)
        { 
            myMode = Mode.Rubber;
            myRB.velocity *= .9f;
        } else if (glue)
        { 
            myMode = Mode.Glue;
            myRB.velocity *= .3f;
        } else
        { 
            myMode = Mode.Nuetral;
        }
        
        mySR.color = myColors[(int)myMode];

        return modeSpeedMod[(int)myMode];
    }

    //Flash to indicate damage taken
    private IEnumerator Blink()
    {
        while(invincible)
        {
            mySR.color = Color.white;
            yield return new WaitForSeconds(invincibleDuration / 5);
            mySR.color = myColors[(int)myMode];
            yield return new WaitForSeconds(invincibleDuration / 5);
        }
        StartCoroutine("LowHealthBlink");
        yield return null;
    }

    //Flash player color to indicate low health
    private IEnumerator LowHealthBlink()
    {
        while (myHealth < maxHealth * .1f && !invincible)
        {
            mySR.color = Color.red;
            yield return new WaitForSeconds(.33f);
            mySR.color = myColors[(int)myMode];
            yield return new WaitForSeconds(.33f);
        }
        yield return null;
    }

    //Damage the player based on the state he's in
    public void ChangeHealth(float diff, int fattyness, bool heal = false)
    {
        if (invincible || GameManager.gameState != GameManager.GameState.Play)
            return;

        myHealth += (int)((heal ? 1 : -1) * Mathf.Abs(diff * damageMod[(int)myMode]));
        ChangeSize(heal, (heal ? fattyness : (int)(diff / 3 + 1)));
        
        if (!heal)
        {
            invincible = true;
            StartCoroutine("Blink");
            invTimer = invincibleDuration;
        }

        myHealth = Mathf.Clamp(myHealth, 0, maxHealth);
    }

    //Change the player's size by count increments
    public void ChangeSize(bool increase, int counts = 1)
    {
        if (counts < 1)
            return;

        mySize += (increase ? 1 : -1) * counts * sizeIncrement;
        mySize = Mathf.Clamp(mySize, minSize, maxSize);
        gameObject.transform.localScale = new Vector3(mySize, mySize, 1);
    }

    //Process collision with projectiles
    private void OnCollisionEnter2D(Collision2D coll)
    {
        if (coll.gameObject.tag == "Projectile")
        {
            if (invincible)
            {
                Destroy(coll.gameObject);
                return;
            }

            Projectile proj = coll.gameObject.GetComponent<Projectile>();
            Rigidbody2D prb = proj.GetComponent<Rigidbody2D>();
            float pStr = prb.velocity.magnitude;
            Vector2 bounceDir = transform.position - proj.transform.position;
            bounceDir.Normalize();

            switch (myMode)
            {
                case Mode.Glue:
                case Mode.Nuetral:
                    //Bounce player
                    if (!proj.good)
                        myRB.AddForce(bounceDir * pStr, ForceMode2D.Impulse);
                    else
                        GameManager.instance.points += proj.points;

                    //Eat projectile, good or bad
                    ChangeHealth(proj.damage, proj.fat, proj.good);

                    Destroy(coll.gameObject);
                    break;

                case Mode.Rubber:
                    //Bounce player
                    myRB.AddForce(bounceDir * pStr * bouncePower, ForceMode2D.Impulse);

                    //Reflect projectile
                    proj.reflected = true;
                    coll.gameObject.layer = LayerMask.NameToLayer("Reflected");
                    if(!proj.good)
                        proj.lifetime += 4;

                    Vector2 reflDir = (coll.contacts[0].normal * -1).normalized;
                    prb.velocity = reflDir * pStr * bouncePower;

                    //Rotate projectile towards new direction
                    float angle = Mathf.Atan2(reflDir.y, reflDir.x) * Mathf.Rad2Deg;
                    proj.transform.rotation = Quaternion.AngleAxis(-angle, Vector3.forward);
                    break;
            }
            
        } else if (coll.gameObject.tag == "Enemy")
        {
            //Bounce away, both take dmg
            Vector2 reflDir = coll.contacts[0].normal.normalized;

            //Enemy reaction, enemy goes first to check invincible
            coll.gameObject.GetComponent<Rigidbody2D>().AddForce(reflDir * -1.5f, ForceMode2D.Impulse);
            if (!invincible)
                coll.gameObject.GetComponent<EnemyBasic>().TakeDamage(3, 2);

            //Player reaction
            myRB.AddForce(reflDir * 1.5f, ForceMode2D.Impulse);
            if(!invincible)
                ChangeHealth(coll.gameObject.GetComponent<EnemyBasic>().meleeDmg, 1);

        } else if (coll.gameObject.tag == "Wall")
        {
            Vector2 reflDir = coll.contacts[0].normal.normalized;
            myRB.AddForce(reflDir * 3, ForceMode2D.Impulse);
        }
    }
    
}
