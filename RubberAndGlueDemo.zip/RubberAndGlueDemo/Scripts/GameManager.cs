﻿using System.Collections;
using System.Collections.Generic;
using System;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour {

    public enum GameState
    {
        Pause,
        Play,
        LevelWin,
        GameOver
    }

    public static GameManager instance = null;
    public static GameState gameState;
    public static int savedPoints = 0;

    public bool mainMenu = false;
    [Tooltip("First Level should be main menu")]
    public string[] Levels;
    public int currentLevel = 0;
    public Canvas canvas;
    public Text hpHUD;
    public Text pointsHUD;
    public Text messageHUD;
    public int points;
    public Player player;

    private bool countDown = false;

    private void Awake()
    {
        if (instance == null)
            instance = this; //Make sure publically accessable GM is this
        else if (instance != this)
            Destroy(gameObject);

        DontDestroyOnLoad(gameObject); //Have one GameManager for everything
    }

    private void Init()
    {
        if (mainMenu)
            return; 

        try
        {
            player = FindObjectOfType<Player>();
            canvas = FindObjectOfType<Canvas>();
            hpHUD = canvas.transform.Find("HP").GetComponent<Text>();
            pointsHUD = canvas.transform.Find("POINTS").GetComponent<Text>();
            messageHUD = canvas.transform.Find("MESSAGE").GetComponent<Text>();

            if (Levels.Length < 1)
                Levels = new string[] { SceneManager.GetActiveScene().name };
            
            points = 0;
            gameState = GameState.Pause;
            Time.timeScale = 1;
            StartCoroutine("Countdown");

        } catch (Exception e)
        {
            Debug.LogError("GM Init fail : " + e);
        }
    }

    void Start ()
    {
        Init();
	}

    private void Update()
    {
        if (Input.GetKeyDown("escape"))
            Application.Quit();

        if (mainMenu)
            return;

        if (Input.GetKeyDown("backspace") && !countDown)
        {
            if (gameState == GameState.Play)
                PauseGame();
            else if (gameState == GameState.Pause)
                ResumeGame();
        }

        if (gameState != GameState.GameOver)
        {
            UpdateHP();
        }

        UpdatePoints();
    }

    //////////////HUD Management
    //Update the HUD text for HP
    private void UpdateHP()
    {
        if(player != null && hpHUD != null)
        {
            if(player.myHealth > 0)
                hpHUD.text = "HP " + player.myHealth.ToString("D2");
            else
            {
                hpHUD.text = "";
                GameOver();
            }
        }
    }

    //Update the HUD text for Points
    private void UpdatePoints()
    {
        if(pointsHUD != null)
        {
            pointsHUD.text = (points + savedPoints).ToString("D5");
        }
    }

    private void UpdateMessage(string msg)
    {
        if (messageHUD != null)
        {
            messageHUD.text = msg;
        }
    }

    //////////////GameState Management
    public void PauseGame()
    {
        gameState = GameState.Pause;
        Time.timeScale = 0;
    }

    public void ResumeGame()
    {
        gameState = GameState.Play;
        Time.timeScale = 1;
    }

    public void GameOver()
    {
        gameState = GameState.GameOver;
        Time.timeScale = .35f;
        UpdateMessage("Game Over!");
        StartCoroutine("EndGame");
    }

    //////////////Level Management
    //Reload the level
    private IEnumerator ResetLevel()
    {
        SceneManager.LoadScene(Levels[currentLevel]);
        yield return new WaitForSecondsRealtime(2);
        points = 0;
        Init();
    }

    //Advance to the next level - Button
    public void ButtonAdvance()
    {
        StartCoroutine("AdvanceScene");
    }
    //Advance to the next level
    private IEnumerator AdvanceScene()
    {
        if (currentLevel < Levels.Length - 1)
            currentLevel++;
        
        SceneManager.LoadScene(Levels[currentLevel]);
        yield return new WaitForSecondsRealtime(2);
        mainMenu = false;
        Init();
    }

    //Return to main menu level
    private void ReturnToMain()
    {
        currentLevel = 0;
        points = 0;
        savedPoints = 0;
        SceneManager.LoadScene(Levels[currentLevel]);
    }

    //////////////Game Management
    //Countdown to start level
    private IEnumerator Countdown()
    {
        countDown = true;
        for (int i = 3; i > 0; i--)
        {
            yield return new WaitForSecondsRealtime(1); //Countdown ignoring time scale
            UpdateMessage(i.ToString()); //Count down on hud
        }
        yield return new WaitForSecondsRealtime(1);
        UpdateMessage("");
        ResumeGame();
        countDown = false;
    }

    private IEnumerator EndGame()
    {
        yield return new WaitForSecondsRealtime(3);
        StartCoroutine("ResetLevel");
    }

    public IEnumerator WinLevel()
    {
        gameState = GameState.LevelWin;
        UpdateMessage("Level Win!");
        yield return new WaitForSecondsRealtime(3);
        UpdateMessage("");
        savedPoints += points + 1000;

        StartCoroutine("AdvanceScene");
    }

}
