﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerControls : MonoBehaviour {

    public float inputSpeedX = 3.0f;
    public float inputSpeedY = 3.0f;
    public float modeMult = 1.0f;

    private Player p;
    private Rigidbody2D rb;
    
	void Start ()
    {
        p = GetComponent<Player>();
        rb = GetComponent<Rigidbody2D>();
	}
	
	void Update ()
    {
        if (GameManager.gameState != GameManager.GameState.Play)
            return;

        var r = Input.GetAxis("Rubber") > 0;
        var g = Input.GetAxis("Glue") > 0;
        var scaleBonus = Mathf.Clamp((p.maxSize / p.mySize), .85f, 2.5f);
        modeMult = p.SetMode(r, g);

        var x = Input.GetAxis("Horizontal") * Time.deltaTime * 100 * inputSpeedX * modeMult * scaleBonus;
        var y = Input.GetAxis("Vertical") * Time.deltaTime * 100 * inputSpeedY * modeMult * scaleBonus;
        
        rb.AddForce(new Vector2(x, y));
        
        rb.velocity = Vector2.ClampMagnitude(rb.velocity, 10);
    }
}
