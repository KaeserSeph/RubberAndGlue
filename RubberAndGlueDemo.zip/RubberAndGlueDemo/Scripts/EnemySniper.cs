﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemySniper : EnemyBasic {

    private bool moveUp = true;

    public override void Init(int tag, int health, GameObject proj, float projSpread, float shotSpd, int dmg)
    {
        base.Init(tag, health, proj, projSpread, shotSpd, dmg);

        shotSpeed *= 2.2f;
        shotSpread = 0;
        damageScale = 2;
        projectileLifetime = 10;
        radius = .5f;
        hp /= 2;
        if (hp < 1)
            hp = 1;
        meleeDmg = 1;
    }

    protected override void UpdateMove()
    {
        //move up and down instead of around 
        Vector2 curPos = transform.position;
        if (curPos.y >= myCenter.y + radius)
            moveUp = false;
        else if (curPos.y <= myCenter.y - radius)
            moveUp = true;

        Vector2 target = new Vector2(myCenter.x, myCenter.y + radius * (moveUp ? 1 : -1));
        Vector2 dir = (target - curPos).normalized;
        dir = new Vector2(0, dir.y);

        myRB.AddForce(dir * moveSpeed);
    }

    protected override float GetWidth()
    {
        return GetComponent<PolygonCollider2D>().bounds.size.x / 2 * 1.2f;
    }

    public override IEnumerator Shoot(bool good)
    {
        if (good || Random.value > .5f) //Shoot half as often
            return base.Shoot(good);
        else
            return null;
    }
}
