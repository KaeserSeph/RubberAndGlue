﻿using System.Collections;
using System.Collections.Generic;
using System;
using UnityEngine;
using Random = UnityEngine.Random;

public class EnemyBasic : MonoBehaviour {

    public GameObject projectile;
    public EnemyController hiveMind;
    public int dogtag;
    public int hp;
    public float shotSpread;
    public float shotSpeed;
    public int damageScale = 1;
    public int projDamage;
    public float projectileLife;
    public float projectileLifetime = 5;
    public int meleeDmg = 3;
    public float hurtDur;

    protected float invDur = .3f;
    protected float invTimer = 0;
    protected float hurtTimer = 0;
    protected bool shooting = false;
    protected Rigidbody2D myRB;
    protected SpriteRenderer mySR;
    protected Color normColor;
    protected Vector2 myCenter;
    protected float moveSpeed = 2f;
    protected int turnDir;
    protected float rotSpeed = 2f; //lower spends longer going around circle
    protected float radius = 1f;
    protected float _angle;
    protected bool isResetting = false;

    public virtual void Init(int tag, int health, GameObject proj, float projSpread, float shotSpd, int dmg)
    {
        try
        {
            dogtag = tag;
            hp = health;
            projectile = proj;
            shotSpread = projSpread;
            shotSpeed = shotSpd;
            projDamage = dmg;
            projectileLife = 5;
            myRB = GetComponent<Rigidbody2D>();
            mySR = GetComponent<SpriteRenderer>();
            normColor = mySR.color;
            myCenter = transform.position;
            turnDir = (Random.value > .5f ? -1 : 1);
        } catch (Exception e)
        {
            Debug.LogError("Enemy Init Fail! : " + e);
        }
    }

    protected void Update()
    {
        if (GameManager.gameState != GameManager.GameState.Play)
            return;
        
        UpdateMove();
        UpdateEnemy();
    }

    protected virtual void UpdateEnemy()
    {
        if (hurtTimer > 0)
            hurtTimer -= Time.deltaTime;

        if (invTimer > 0)
            invTimer -= Time.deltaTime;


        myRB.velocity = Vector2.ClampMagnitude(myRB.velocity, 10);
    }

    //Update movement
    protected virtual void UpdateMove()
    {
        _angle += rotSpeed * Time.deltaTime * turnDir;

        Vector2 offset = new Vector2(Mathf.Sin(_angle), Mathf.Cos(_angle)) * radius;
        Vector2 target = myCenter + offset;
        Vector2 curPos = transform.position;
        Vector2 dir = (target - curPos).normalized;

        myRB.AddForce(dir * moveSpeed);
    }

    protected void ResetStart()
    {
        myCenter = -myRB.velocity.normalized * radius;
        isResetting = false;
    }

    //Apply damage to this enemy, update score accordingly
    public void TakeDamage(int dmg, int points)
    {
        if (invTimer > 0 || GameManager.gameState != GameManager.GameState.Play)
            return;

        hp -= dmg;

        //give player points for reflected damage
        GameManager.instance.points += points * (hp < 0 ? 3 : 1);
        if (hp < 0)
            hiveMind.EnemyDeath(gameObject);
        else
        {
            invTimer = invDur;
            hurtTimer = hurtDur;
            StartCoroutine("Blink");
        }
    }

    //Visually display taking damage
    protected IEnumerator Blink()
    {
        while (hurtTimer > 0)
        {
            mySR.color = Color.white;
            yield return new WaitForSeconds(hurtDur / 5);
            mySR.color = normColor;
            yield return new WaitForSeconds(hurtDur / 5);
        }
        yield return null;
    }

    //Overwritable get width for differences in collider
    protected virtual float GetWidth()
    {
        return GetComponent<CircleCollider2D>().radius * 1.2f;
    }

    //Fire projectile
    public virtual IEnumerator Shoot(bool good)
    {
        if (!shooting)
        {
            try
            {
                //Create projectile spawn location 
                Vector3 start = transform.position;
                Vector3 playerPos = hiveMind.player.transform.position;
                Vector2 dir = (new Vector3(playerPos.x + Random.Range(-shotSpread, shotSpread), playerPos.y + Random.Range(-shotSpread, shotSpread), 1) - start).normalized;
                float radius = GetWidth();
                Vector3 spawnLoc = new Vector3(start.x + (dir * radius).x, start.y + (dir * radius).y, 0); //spawn away from me

                //Create projectile
                GameObject proj = Instantiate(projectile, spawnLoc, Quaternion.identity);
                Projectile bullet = proj.GetComponent<Projectile>();
                bullet.lifetime = projectileLifetime;
                int fat = Random.Range(1, 4);
                if (good)
                    bullet.SetGood(fat, hiveMind.goodPointScale * fat);
                else
                    bullet.SetPain(fat, hiveMind.painPointScale * fat, projDamage * damageScale);

                //Shoot projectile
                Rigidbody2D prb = proj.GetComponent<Rigidbody2D>();
                float angle = Mathf.Atan2(dir.y, dir.x) * Mathf.Rad2Deg;
                proj.transform.rotation = Quaternion.AngleAxis(-angle, Vector3.forward);
                prb.velocity = dir * shotSpeed;
            }
            catch (Exception e)
            {
                Debug.LogError("Shoot fail! : " + e);
            }
        }
        yield return null;
    }

    //Process collisions
    protected void OnCollisionEnter2D(Collision2D coll)
    {
        bool reset = false; //make sure it's worth changing centerpoint

        if (coll.gameObject.tag == "Projectile")
        {
            reset = true;
            Projectile proj = coll.gameObject.GetComponent<Projectile>();

            if (proj.reflected)
            {
                if (!proj.good)
                    TakeDamage(proj.damage, proj.points);

                Destroy(coll.gameObject);
            }
        }
        else if (coll.gameObject.tag == "Enemy")
        {
            reset = true;
            //Enemies bounce away from each other if colliding
            Vector2 reflDir = coll.contacts[0].normal.normalized;
            myRB.AddForce(reflDir * 1.5f, ForceMode2D.Impulse);
        }
        else if (coll.gameObject.tag == "Wall")
        {
            reset = true;
            Vector2 reflDir = coll.contacts[0].normal.normalized;
            myRB.AddForce(reflDir * 3, ForceMode2D.Impulse);
        }

        if (reset && !isResetting)
        {
            isResetting = true;
            Invoke("ResetStart", .75f);
        }
    }

}
