﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using Random = UnityEngine.Random;

public class EnemyController : MonoBehaviour {

    public bool debugMode = false; //debug mode to use input for testing

    public Player player;
    [Tooltip("Left, Right, Top, Bottom")]
    public float[] boundaries;
    public GameObject[] EnemyTypes;
    public GameObject[] Projectiles;

    [Header("Enemy Stats")]
    public int EnemiesToKill;
    public int EnemiesDead;
    public float spawnRate = 3.0f;
    [Tooltip("Inverse of Shot Rate is how long to wait per shot")]
    public float shotRate;
    public int MaxEnemies;
    public int MinHp;
    public int MaxHp;
    public int DamageBase;
    public float MinSpread;
    public float MaxSpread;
    public float ShotSpeed;
    public int goodPointScale;
    public int painPointScale;

    private int dogtag = 10000;
    private float spawnTimer;
    private float shotTimer;
    private List<GameObject> Enemies = new List<GameObject>();
    private bool spawning = false;

    private void Init()
    {
        if (!player)
            player = FindObjectOfType<Player>();

        if (player && boundaries.Length == 4 && EnemyTypes.Length > 0 && Projectiles.Length > 0 && MaxEnemies > 0 && EnemiesToKill > 0)
        {
            Debug.Log("Hive Mind Active");
            spawnTimer = 0;
            EnemiesDead = 0;
        }
        else
        {
            Debug.LogError("Hive Mind Failure");
        }
    }

    void Start ()
    {
        Init();
	}

    private void Update()
    {
        if (GameManager.gameState != GameManager.GameState.Play)
            return;

        if (Enemies.Count < MaxEnemies)
        {
            spawnTimer += Time.deltaTime;

            if (spawnTimer > spawnRate)
            {
                StartCoroutine("CreateEnemy");
                spawnTimer = 0;
            }
        }
        else
            spawnTimer = 0;

        if(Enemies.Count > 0)
        {
            if (debugMode)
            {
                if (Input.GetKeyDown("space"))
                    UpdateEnemyAttack(true);

                if (Input.GetKeyDown("delete") && Enemies.Count > 0)
                    EnemyDeath(Enemies[0]);
            } else
            {
                shotTimer += Time.deltaTime;

                if (shotTimer > 1 / shotRate)
                {
                    UpdateEnemyAttack();
                    shotTimer = 0;
                }
            }
        }
    }

    //Command enemies to attack
    private void UpdateEnemyAttack(bool trueShot = false)
    {
        foreach(GameObject en in Enemies)
        {
            if(Random.value > .45f || trueShot)
                en.GetComponent<EnemyBasic>().StartCoroutine("Shoot", Random.value > .85f);
        }
    }

    //Instantiate an enemy and it add to the Enemy list
    private IEnumerator CreateEnemy()
    {
        if (!spawning)
        {
            try
            {
                spawning = true;
                //Spawn randomly, but not where can't fit
                float pX = player.transform.position.x;
                float pW = player.GetComponent<PolygonCollider2D>().bounds.size.x / 2;
                float pY = player.transform.position.y;
                bool l = Mathf.Abs(boundaries[0] - (pX - pW)) > pW + .5f; //left
                bool r = Mathf.Abs(boundaries[1] - (pX + pW)) > pW + .5f; //right
                bool t = Mathf.Abs(boundaries[2] - (pY + pW)) > pW + .5f; //top
                bool b = Mathf.Abs(boundaries[3] - (pY - pW)) > pW + .5f; //bottom
                float horiz, vert;

                if (l && r)
                    horiz = Random.value > .5f ? Random.Range(boundaries[0], pX - pW) : Random.Range(pX + pW, boundaries[1]);
                else if (l && !r)
                    horiz = Random.Range(boundaries[0], pX - pW);
                else //(!l && r)
                    horiz = Random.Range(pX + pW, boundaries[1]);

                if (t && b)
                    vert = Random.value > .5f ? Random.Range(pY + pW, boundaries[2]) : Random.Range(boundaries[3], pY - pW);
                else if (t && !b)
                    vert = Random.Range(pY + pW, boundaries[2]);
                else //(!t && b)
                    vert = Random.Range(boundaries[3], pY - pW);
                
                Vector3 loc = new Vector3(horiz, vert, 0);

                GameObject newEnemy = Instantiate(EnemyTypes[Random.Range(0, EnemyTypes.Length)], loc, Quaternion.identity, gameObject.transform);
                Enemies.Add(newEnemy);

                newEnemy.GetComponent<EnemyBasic>().Init(
                    dogtag++,
                    Random.Range(MinHp, MaxHp),
                    Projectiles[Random.Range(0, Projectiles.Length)],
                    Random.Range(MinSpread, MaxSpread),
                    ShotSpeed,
                    DamageBase);

                newEnemy.GetComponent<EnemyBasic>().hiveMind = this;
            } catch (Exception e)
            {
                Debug.LogError("CreateEnemy Failure! : " + e);
            }
            spawning = false;
        }
        yield return null;
    }

    //Purge an enemy from the list and destroy the object
    public void EnemyDeath(GameObject enemy)
    {
        if (Enemies.Remove(enemy))
        {
            EnemyBasic e = enemy.GetComponent<EnemyBasic>();
            Debug.Log("Enemy down! Poor #" + e.dogtag + "! He won't be missed...\n" + Enemies.Count + " of our finest alive!");
            Destroy(enemy);

            EnemiesDead++;
            if(EnemiesDead >= EnemiesToKill)
                GameManager.instance.StartCoroutine("WinLevel");
            
        }
        else
        {
            Debug.LogError("Enemy Death failure! Could not find enemy to remove from our ranks.");
        }
    }

}
